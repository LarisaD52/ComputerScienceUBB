#include "GUI.h"
#include <qdebug.h>

GUI::GUI(const std::vector<Gene>& genes, QWidget *parent)
	: QWidget(parent), genes{ genes }
{
	ui.setupUi(this);
	this->populateList();

	QObject::connect(this->ui.addButton, &QPushButton::clicked, this, &GUI::addButtonHandler);
}

GUI::~GUI()
{}

void GUI::populateList()
{
	for (auto g : this->genes) {
		this->ui.genesListWidget->addItem(QString::fromStdString(g.toString()));
	}
}

void GUI::addButtonHandler()
{
	qDebug() << "Add was pressed!\n";
}
