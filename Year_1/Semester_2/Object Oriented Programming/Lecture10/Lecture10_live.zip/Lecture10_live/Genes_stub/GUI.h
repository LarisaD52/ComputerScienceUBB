#pragma once

#include <QWidget>
#include "ui_GUI.h"
#include "Gene.h"

class GUI : public QWidget
{
	Q_OBJECT

public:
	GUI(const std::vector<Gene>& genes, QWidget *parent = nullptr);
	~GUI();

private:
	Ui::GUIClass ui;
	std::vector<Gene> genes;

	void populateList();
	void addButtonHandler();
};
