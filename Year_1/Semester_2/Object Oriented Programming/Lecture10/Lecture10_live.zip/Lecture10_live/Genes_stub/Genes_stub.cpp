#include "Genes_stub.h"

Genes_stub::Genes_stub(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Genes_stub::~Genes_stub()
{}
