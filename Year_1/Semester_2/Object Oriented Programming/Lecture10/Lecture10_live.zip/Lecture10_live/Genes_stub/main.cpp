#include "Genes_stub.h"
#include <QtWidgets/QApplication>
#include "Gene.h"
#include "GUI.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    
    std::vector<Gene> genes{ Gene{ "yqgE", "E_Coli_K12", "ATGAATTTACAGCAT" },
                            Gene{ "ppiA", "M_tuberculosis", "TTTTCATCACCGTCGG" },
                            Gene{ "Col2a1", "Mouse", "TTAAAGCATGGCTCTGTG" } };

    GUI gui{genes};
    gui.show();
    
    return a.exec();
}
