#include "GUI.h"

GUI::GUI(Model* model, QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	this->model = model;
	ui.tableView->setModel(this->model);

	this->ui.lineEdit->setText(QString::number(this->model->getTotal()));

	connect(ui.pushButton, &QPushButton::clicked, this, &GUI::addNewProduct);
	connect(this->model, &Model::totalChanged, this, &GUI::updateTotal);
}

GUI::~GUI()
{}

void GUI::addNewProduct()
{
	Product p{ "Honey", 40 };
	this->model->addProduct(p);
}

void GUI::updateTotal()
{
	this->ui.lineEdit->setText(QString::number(this->model->getTotal()));
}
