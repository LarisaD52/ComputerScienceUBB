#pragma once

#include <QWidget>
#include "ui_GUI.h"
#include "Model.h"

class GUI : public QWidget
{
	Q_OBJECT

public:
	GUI(Model* model, QWidget *parent = nullptr);
	~GUI();

private:
	Ui::GUIClass ui;
	Model* model;

	void addNewProduct();
	void updateTotal();
};
