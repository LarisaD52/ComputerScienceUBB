#include "Model.h"

int Model::rowCount(const QModelIndex& parent) const
{
    return basket.getSize();
}

int Model::columnCount(const QModelIndex& parent) const
{
    return 2;
}

QVariant Model::data(const QModelIndex& index, int role) const
{
    int row = index.row();
    int col = index.column();

    Product p = basket.getAll()[row];

    if (role == Qt::DisplayRole) {
        if (col == 0)
            return QString::fromStdString(p.getName());
        else if (col == 1)
            return QString::number(p.getPrice());
    }

    return QVariant();
}

void Model::addProduct(const Product& p)
{
    int size = this->basket.getSize();
    beginInsertRows(QModelIndex{}, size, size);
    this->basket.addProduct(p);
    endInsertRows();
    emit totalChanged();
}

double Model::getTotal()
{
    return this->basket.getTotal();
}
