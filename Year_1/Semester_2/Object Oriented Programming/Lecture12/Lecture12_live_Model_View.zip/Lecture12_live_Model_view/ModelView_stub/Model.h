#pragma once
#include <QAbstractTableModel>
#include "ShoppingBasket.h"

class Model :
    public QAbstractTableModel
{
	Q_OBJECT

private:
    ShoppingBasket& basket;

public:
    Model(ShoppingBasket& basket) : basket{ basket } {}

	int rowCount(const QModelIndex& parent = QModelIndex{}) const override;							// provides the number of rows for the table
	int columnCount(const QModelIndex& parent = QModelIndex{}) const override;						// provides the number of columns for the table
	QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;				// provides the text content for a cell

	// add header data
	//QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;

	//bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole) override;	// will be called when a cell is edited
	//Qt::ItemFlags flags(const QModelIndex& index) const override;										// used to set certain properties of a cell

	void addProduct(const Product& p);

	double getTotal();

signals:
	void totalChanged();
};

