#include "ProductsModel.h"
#include <QBrush>
#include <QFont>

ProductsModel::ProductsModel(ShoppingBasket& basket): basket{basket}
{
}

int ProductsModel::rowCount(const QModelIndex& parent) const
{
	return this->basket.getSize();
}

int ProductsModel::columnCount(const QModelIndex& parent) const
{
	return 2;
}

QVariant ProductsModel::data(const QModelIndex& index, int role) const
{
	int row = index.row();
	int col = index.column();

	Product p = this->basket.getAll()[row];

	if (role == Qt::DisplayRole) {
		if (col == 0)
			return QString::fromStdString(p.getName());
		if (col == 1)
			return QString::number(p.getPrice());
	}

	if (role == Qt::BackgroundRole) {
		if (row % 2 == 1) {
			return QBrush{ QColor{134, 220, 180} };
		}
	}

	if (role == Qt::FontRole) {
		return QFont{ "Verdana", 16 };
	}

	return QVariant();
}

QVariant ProductsModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole)
	{
		if (orientation == Qt::Horizontal) {
			if (section == 0)
				return "Product name";
			else
				return "Price";
		}
	}

	if (role == Qt::FontRole) {
		if (orientation == Qt::Horizontal)
			return QFont{ "Verdana", 16 };
	}

	return QVariant();
}

double ProductsModel::getTotal() const
{
	return this->basket.getTotal();
}

void ProductsModel::addProduct(const Product& p)
{
	int size = this->basket.getSize();
	beginInsertRows(QModelIndex{}, size, size);
	this->basket.addProduct(p);
	endInsertRows();
	emit totalWasChanged();
}
