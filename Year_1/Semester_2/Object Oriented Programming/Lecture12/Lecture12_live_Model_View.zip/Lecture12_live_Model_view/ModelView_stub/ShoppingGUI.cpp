#include "ShoppingGUI.h"

ShoppingGUI::ShoppingGUI(ProductsModel* model, QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	this->model = model;
	ui.shoppingBasketView->setModel(this->model);
	this->ui.shoppingBasketView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	this->ui.totalLineEdit->setText(QString::number(this->model->getTotal()));

	connect(this->ui.addButton, &QPushButton::clicked,
		this, &ShoppingGUI::addButtonHandler);
	connect(this->model, &ProductsModel::totalWasChanged, this, [this] {
		this->ui.totalLineEdit->setText(QString::number(this->model->getTotal()));
		});
}

ShoppingGUI::~ShoppingGUI()
{}

void ShoppingGUI::addButtonHandler()
{
	Product p{ "Honey", 100 };
	this->model->addProduct(p);
}
