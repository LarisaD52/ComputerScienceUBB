#pragma once

#include <QWidget>
#include "ui_ShoppingGUI.h"
#include "ProductsModel.h"

class ShoppingGUI : public QWidget
{
	Q_OBJECT

public:
	ShoppingGUI(ProductsModel* model, QWidget *parent = nullptr);
	~ShoppingGUI();

private:
	Ui::ShoppingGUIClass ui;
	ProductsModel* model;

	void addButtonHandler();
};
