#include "DynamicArray.h"
#include <stdlib.h>

DynamicArray* createArray(int capacity, DestructionFunction destroyF)
{
    DynamicArray* arr = malloc(sizeof(DynamicArray));
    if (arr == NULL)
        return NULL;
    arr->size = 0;
    arr->capacity = capacity;
    arr->destroyFct = destroyF;
    arr->elems = malloc(arr->capacity * sizeof(TElem));
    if (arr->elems == NULL)
    {
        free(arr);
        return NULL;
    }
    return arr;
}

void destroyArray(DynamicArray* arr)
{
    if (arr == NULL)
        return;
    for (int i = 0; i < arr->size; i++)
        arr->destroyFct(arr->elems[i]);
    free(arr->elems);
    arr->elems = NULL;
    free(arr);
}

void resize(DynamicArray* arr) {
    if (arr == NULL || arr->elems == NULL)
        return;
    arr->capacity *= 2;
    TElem* aux = realloc(arr->elems, arr->capacity * sizeof(TElem));
    if (aux == NULL)
        return;
    arr->elems = aux;
}

void addElem(DynamicArray* arr, TElem elem)
{
    if (arr == NULL || arr->elems == NULL)
        return;
    if (arr->size == arr->capacity)
        resize(arr);
    arr->elems[arr->size++] = elem;
}

int getSize(DynamicArray* arr)
{
    if (arr == NULL)
        return -1;
    return arr->size;
}
