#pragma once
#include "Planet.h"

typedef void* TElem;

typedef void (*DestructionFunction)(TElem);

typedef struct {
	TElem* elems;
	int size, capacity;
	DestructionFunction destroyFct;
} DynamicArray;

DynamicArray* createArray(int capacity, DestructionFunction destroyF);
void destroyArray(DynamicArray* arr);
void addElem(DynamicArray* arr, TElem elem);
int getSize(DynamicArray* arr);
//void deleteElem(DynamicArray* arr, int idx);