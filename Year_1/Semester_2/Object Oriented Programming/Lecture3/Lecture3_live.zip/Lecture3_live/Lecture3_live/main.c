#include "DynamicArray.h"
#include <assert.h>
#include <crtdbg.h>

void testArray() {
	DynamicArray* arr = createArray(1, &destroyPlanet);

	Planet* p1 = createPlanet("Mars", "Terrestrial", 2);
	Planet* p2 = createPlanet("Jupiter", "Gas giant", 3);
	Planet* p3 = createPlanet("Saturn", "Gas", 4);

	addElem(arr, p1);
	assert(getSize(arr) == 1);

	addElem(arr, p2);
	assert(getSize(arr) == 2);

	addElem(arr, p3);
	assert(getSize(arr) == 3);

	destroyArray(arr);
}

void testArrayOfArrays() {
	DynamicArray* arrOfArrays = createArray(1, &destroyArray);

	DynamicArray* arrPlanets1 = createArray(2, &destroyPlanet);
	DynamicArray* arrPlanets2 = createArray(2, &destroyPlanet);
	Planet* p1 = createPlanet("Mars", "Terrestrial", 2);
	Planet* p2 = createPlanet("Jupiter", "Gas giant", 3);
	Planet* p3 = createPlanet("Saturn", "Gas", 4);

	addElem(arrPlanets1, p1);
	addElem(arrPlanets1, p2);
	addElem(arrPlanets2, p3);

	addElem(arrOfArrays, arrPlanets1);
	addElem(arrOfArrays, arrPlanets2);
	assert(getSize(arrOfArrays) == 2);

	destroyArray(arrOfArrays);
}

int main() {
	testArray();

	_CrtDumpMemoryLeaks();
	return 0;
}