#include "Book.h"
#include <iostream>

Book::Book(): author{""}, title{""}, year{0}, review{0}
{
}

Book::Book(const std::string& author,
	const std::string& title, 
	int year, int review): author{author}, title{title},
	year{year}, review{review}
{
	/*this->author = author;
	this->title = title;
	this->year = year;
	this->review = review;*/
}

Book::~Book()
{
	// std::cout << "Destructor of book called";
}

Book::Book(const Book& b)
{
	this->author = b.author;
	this->title = b.title;
	this->year = year;
	this->review = review;
}

void Book::setReview(int review)
{
	if (review < 0 || review > 5)
		return;
	this->review = review;
}
