#pragma once
#include <iostream>
#include <string>

class Book
{
private:
	std::string author;
	std::string title;
	int year;
	int review;

public:
	Book();
	Book(const std::string& author, 
		const std::string& title,
		int year, int review);
	~Book();
	Book(const Book& b);

	std::string getAuthor() const { return this->author; }
	void setReview(int review);
};

