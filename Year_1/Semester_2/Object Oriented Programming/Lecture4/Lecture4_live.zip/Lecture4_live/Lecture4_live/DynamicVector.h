#pragma once
#include "Book.h"

typedef Book TElem;

class DynamicVector
{
private:
	int size, capacity;
	TElem* elems;

public:
	DynamicVector(int capacity = 10);
	~DynamicVector();
	DynamicVector(const DynamicVector& v);
	DynamicVector& operator=(const DynamicVector& v);
};

