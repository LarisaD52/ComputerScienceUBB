#include "Book.h"
#include <iostream>
#include <crtdbg.h>
#include "DynamicVector.h"

using namespace std;

int main() {
	{
		Book b{ "Ian Goodfellow", "Deep Learning", 2010, 5 };
		cout << b.getAuthor() << endl;

		Book b2{ b };
		//Book b2 = b;

		Book* pBook = new Book{ "Ian Goodfellow", "Deep Learning", 2010, 5 };
		delete pBook;

		Book arrayOfBooks[100];
		Book* arrayOfBooks2 = new Book[100];
		delete[] arrayOfBooks2;

		DynamicVector v1{5};
		//DynamicVector v2 = v1;
		DynamicVector v2{ v1 };

		DynamicVector v3{};
		//v3 = v1 = v2;
		//v3.operator=(v1.operator=(v2));
		v3 = v1;
		v3.operator=(v1);

		v3 = v3;
	}

	_CrtDumpMemoryLeaks();

	return 0;
}