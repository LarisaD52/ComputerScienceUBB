#include "Filter.h"

FilterWeightLessThan::FilterWeightLessThan(double w): weight{w}
{
}

bool FilterWeightLessThan::include(Animal& a)
{
	if (a.getWeight() < this->weight)
		return true;
	return false;
}

FilterColour::FilterColour(const std::string& col): colour{col}
{
}

bool FilterColour::include(Animal& a)
{
	if (a.getColour() == this->colour)
		return true;
	return false;
}
