#pragma once
#include "Animal.h"

class Filter
{
public:
	virtual bool include(Animal& a) = 0;
};

class FilterWeightLessThan : public Filter {
private:
	double weight;

public:
	FilterWeightLessThan(double w);
	bool include(Animal& a) override;
};

class FilterColour : public Filter {
private:
	std::string colour;

public:
	FilterColour(const std::string& col);
	bool include(Animal& a) override;
};
