#include "Zoo.h"

Zoo::Zoo(std::vector<Animal*> animals): animals{animals}
{
}

std::vector<Animal*> Zoo::filterBy(Filter& filter)
{
    std::vector<Animal*> filteredAnimals{};
    for (Animal* a : this->animals) {
        if (filter.include(*a))
            filteredAnimals.push_back(a);
    }
    return filteredAnimals;
}
