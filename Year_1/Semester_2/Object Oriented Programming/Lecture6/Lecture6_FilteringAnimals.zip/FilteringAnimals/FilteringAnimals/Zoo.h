#pragma once
#include <vector>
#include "Animal.h"
#include "Filter.h"

class Zoo
{
private:
	std::vector<Animal*> animals;

public:
	Zoo(std::vector<Animal*> animals);
	std::vector<Animal*> filterBy(Filter& filter);
};

