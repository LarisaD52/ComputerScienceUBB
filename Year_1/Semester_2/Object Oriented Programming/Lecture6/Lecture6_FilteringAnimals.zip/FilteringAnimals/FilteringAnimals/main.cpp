#include "Zoo.h"
#include "Penguin.h"
#include "Dog.h"
#include <iostream>
#include <crtdbg.h>

using namespace std;

vector<Animal*> createAnimals() {
	vector<Animal*> animals;
	Animal* p1 = new Penguin{ "black", 7, "Magellanic" };
	Animal* p2 = new Penguin{ "white and black", 6, "Emperor" };
	Animal* d1 = new Dog{ "black", 35, "rottweiler", 2 };
	Animal* d2 = new Dog{ "beige", 25, "Labrador retriever", 4 };

	animals.push_back(p1);
	animals.push_back(d1);
	animals.push_back(p2);
	animals.push_back(d2);

	return animals;
}

void destroyAnimals(vector<Animal*> animals) {
	for (Animal* a : animals)
		delete a;
}

void filterAnimals() {
	vector<Animal*> animals = createAnimals();
	Zoo zoo{ animals };

	/*Filter* f = new FilterWeightLessThan{ 30 };
	vector<Animal*> weightLessThan30Animals = zoo.filterBy(*f);*/

	FilterWeightLessThan filterWeight{ 30 };
	vector<Animal*> weightLessThan30Animals = zoo.filterBy(filterWeight);
	cout << "Animals having a weight less than 30: " << endl;
	for (auto a : weightLessThan30Animals)
		cout << a->toString() << endl;

	FilterColour filterColour{ "black" };
	vector<Animal*> colourBlackAnimals = zoo.filterBy(filterColour);
	cout << "Animals having the colour black: " << endl;
	for (auto a : colourBlackAnimals)
		cout << a->toString() << endl;

	destroyAnimals(animals);
}

int main()
{
	filterAnimals();

	_CrtDumpMemoryLeaks();

	return 0;
}