//#include <stdio.h>
//#include <Windows.h>
//
//int main()
//{
//	system("color f4");
//
//	printf("Hello world!\n");
//
//	return 0;
//}