#include "Lecture10_Notepad_example.h"

Lecture10_Notepad_example::Lecture10_Notepad_example(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture10_Notepad_example::~Lecture10_Notepad_example()
{}
