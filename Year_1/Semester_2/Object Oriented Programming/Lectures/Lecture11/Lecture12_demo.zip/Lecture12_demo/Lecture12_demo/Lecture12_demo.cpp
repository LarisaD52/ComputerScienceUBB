#include "Lecture12_demo.h"

Lecture12_demo::Lecture12_demo(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture12_demo::~Lecture12_demo()
{}
