#include "Lecture12_demo_strategy.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Lecture12_demo_Strategy w;
    w.show();
    return a.exec();
}
