#include "Observer_stub.h"
#include <QtWidgets/QApplication>
#include "ShoppingBasketWidget.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	
	ShoppingBasket basket{};
	basket.addProduct(Product{ "Apples", 18 });
	basket.addProduct(Product{ "Butter", 16 });
	basket.addProduct(Product{ "Orange juice", 22 });
	basket.addProduct(Product{ "Surgical mask", 3 });

	ShoppingBasketWidget w1{basket};
	basket.addObserver(&w1);
	w1.show();

	ShoppingBasketWidget w2{ basket };
	basket.addObserver(&w2);
	w2.show();

	ShoppingBasketWidget w3{ basket };
	basket.addObserver(&w3);
	w3.show();

	return a.exec();
}
