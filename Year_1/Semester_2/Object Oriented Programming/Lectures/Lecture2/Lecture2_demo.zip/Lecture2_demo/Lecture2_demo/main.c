//#include "DynamicArray.h"
//#include <windows.h>
//#include <crtdbg.h>
//
//int main()
//{
//	system("color f4");
//
//	//testsDynamicArray();
//	_CrtDumpMemoryLeaks();
//
//	return 0;
//}