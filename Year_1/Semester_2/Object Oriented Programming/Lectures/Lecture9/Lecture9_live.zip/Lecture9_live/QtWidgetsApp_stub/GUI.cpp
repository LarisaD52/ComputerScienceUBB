#include "GUI.h"
#include <qboxlayout.h>
#include <qformlayout.h>
#include <qlabel.h>

GUI::GUI(Service& s): serv{s}
{
	this->initGUI();
	this->populateList();

	QObject::connect(this->addButton, &QPushButton::clicked, this, &GUI::addButtonHandler);
}

void GUI::initGUI()
{
	QHBoxLayout* mainLayout = new QHBoxLayout{ this };
	this->spaceshipsListW = new QListWidget{};
	mainLayout->addWidget(this->spaceshipsListW);

	QVBoxLayout* rightLayout = new QVBoxLayout{};
	QFormLayout* spaceShipAttributesLayout = new QFormLayout{};
	QLabel* nameLabel = new QLabel{ "Name" };
	/*QFont font{ "Verdana", 20 };
	nameLabel->setFont(font);*/
	QLabel* captainLabel = new QLabel{ "Captain" };
	QLabel* typeLabel = new QLabel{ "Type" };
	this->nameEdit = new QLineEdit{};
	this->captainEdit = new QLineEdit{};
	this->typeEdit = new QLineEdit{};
	spaceShipAttributesLayout->addRow(nameLabel, this->nameEdit);
	spaceShipAttributesLayout->addRow(captainLabel, this->captainEdit);
	spaceShipAttributesLayout->addRow(typeLabel, this->typeEdit);
	rightLayout->addLayout(spaceShipAttributesLayout);

	mainLayout->addLayout(rightLayout);

	QHBoxLayout* buttonsLayout = new QHBoxLayout{};
	this->addButton = new QPushButton{"Add"};
	this->deleteButton = new QPushButton{"Delete"};
	buttonsLayout->addWidget(this->addButton);
	buttonsLayout->addWidget(this->deleteButton);
	rightLayout->addLayout(buttonsLayout);
}

void GUI::populateList()
{
	this->spaceshipsListW->clear();

	std::vector<Spaceship> spaceships = this->serv.getAll();
	for (auto& spaceship : spaceships)
	{
		std::string str = spaceship.getName() + " - " + spaceship.getCaptain();
		/*QListWidgetItem* item = new QListWidgetItem{QString::fromStdString(str)};
		QFont font{ "Verdana", 15 };
		item->setFont(font);*/
		this->spaceshipsListW->addItem(QString::fromStdString(str));
	}
}

void GUI::addButtonHandler()
{
	QString name = this->nameEdit->text();
	QString captain = this->captainEdit->text();
	QString type = this->typeEdit->text();
	this->serv.add(name.toStdString(), type.toStdString(), captain.toStdString());
	this->populateList();
}