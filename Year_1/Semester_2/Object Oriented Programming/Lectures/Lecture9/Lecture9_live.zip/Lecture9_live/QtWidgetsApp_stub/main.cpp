#include <QtWidgets/QApplication>
#include <qlabel.h>
#include "GUI.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Repository repo{ "Spaceships.csv" };
    Service service{ repo };
    GUI gui{ service };
    gui.show();

    return a.exec();
}
